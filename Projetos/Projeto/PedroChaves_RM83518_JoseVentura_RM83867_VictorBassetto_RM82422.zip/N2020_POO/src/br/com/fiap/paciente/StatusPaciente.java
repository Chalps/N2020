package br.com.fiap.paciente;

public enum StatusPaciente {
    filaAtendimento, filaInternacao, internado, liberado, emAlta, obito;
}
